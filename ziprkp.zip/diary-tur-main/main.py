# İçe aktar
from flask import Flask, render_template,request, redirect
# Veri tabanı kitaplığını bağlama
from flask_sqlalchemy import SQLAlchemy


app = Flask(__name__)
# SQLite'ı bağlama
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///diary.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
# Veri tabanı oluşturma
db = SQLAlchemy(app)
# Tablo oluşturma



class Card(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    text = db.Column(db.String)
    # Nesnenin ve kimliğin çıktısı
    def __repr__(self):
        return f'<Card {self.id}>'
    

#Ödev #2. Kullanıcı tablosunu oluşturun

class User(db.Model):
    # Sütunları oluşturma
     # kimlik
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    username = db.Column(db.String(30), nullable=False)
    password = db.Column(db.String(40),nullable=False)

    def __repr__(self):
        return f'<User {self.id}>'


# İçerik sayfasını çalıştırma
@app.route('/', methods=['GET','POST'])
def login():
        error = ''
        if request.method == 'POST':
            form_login = request.form['username']
            form_password = request.form['password']
            
            #Ödev #4. yetkilendirmeyi uygulamak
            users_db = User.query.all()
            for user in users_db:
                if form_login == user.username and form_password == user.password:     
                    return redirect('/rkp')
                    
            else:
                error = 'Incorrect login or password'
            return render_template('login.html', error=error)
            
        else:
            return render_template('login.html')



@app.route('/reg', methods=['GET','POST'])
def reg():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        #Ödev #3 Kullanıcı verilerinin veri tabanına kaydedilmesini sağlayın
        user = User(username=username, password=password)
        db.session.add(user)
        db.session.commit()
        return redirect('/')
    
    else:    
        return render_template('registration.html')

@app.route('/rkp', methods=['POST', "GET"])
def form():
    texty = request.form.get("text")
    card = Card(text=texty)
    db.session.add(card)
    db.session.commit()
    return render_template("index.html")



if __name__ == "__main__":
    app.run(debug=True)